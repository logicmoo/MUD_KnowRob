#!/bin/sh
swipl -x /opt/eye/lib/eye.pvm -- "$@"
